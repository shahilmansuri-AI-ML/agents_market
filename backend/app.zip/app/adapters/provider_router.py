import logging
import time

from app.adapters.groq_adapter import generate as groq_generate
from app.adapters.gemini_adapter import generate as gemini_generate
from app.runtime.errors import RetryableStepError, NonRetryableStepError

logger = logging.getLogger(__name__)

# Primary model — Gemini 1.5-flash (used for all user-selected models with "gemini" in the name)
PRIMARY_MODEL   = "gemini-1.5-flash"
PRIMARY_PROVIDER = "gemini"

# Fallback — Groq (used when Gemini fails with a retryable error)
FALLBACK_MODEL    = "llama-3.1-8b-instant"
FALLBACK_PROVIDER = "groq"


def _get_provider(model_name: str) -> str:
    """Map model name → provider. Any gemini* model routes to gemini, everything else to groq."""
    if not model_name:
        return PRIMARY_PROVIDER

    lower = model_name.strip().lower()

    if lower.startswith("gemini"):
        return "gemini"

    # All other models fall back to groq
    return "groq"


def generate(messages: list, model: str = None) -> str:
    model_name = (model or PRIMARY_MODEL).strip()
    provider   = _get_provider(model_name)

    logger.info(f"[ProviderRouter] model='{model_name}' → provider='{provider}'")

    if provider == "gemini":
        try:
            logger.info("[LLM] Using Gemini | model=%s", model_name)

            time.sleep(1.5)  # prevent rate limit
            return gemini_generate(messages, model_name)

        except Exception as e:
            error_str = str(e).lower()

           
            if (
                isinstance(e, RetryableStepError)
                or "429" in error_str
                or "quota" in error_str
                or "timeout" in error_str
                or "connection" in error_str
            ):
                logger.warning(
                    f"[ProviderRouter] Gemini failed ({e}). Falling back to Groq"
                )
                logger.info("[LLM] Using Groq | model=%s", FALLBACK_MODEL)
                return groq_generate(messages, FALLBACK_MODEL)

            raise

    # Groq direct
    logger.info("[LLM] Using Groq | model=%s", model_name)
    return groq_generate(messages, model_name)