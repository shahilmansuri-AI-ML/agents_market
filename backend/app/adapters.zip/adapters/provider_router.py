import logging
from app.runtime.errors import NonRetryableStepError

logger = logging.getLogger(__name__)

# Maps model name (as saved in agent config) → provider key
MODEL_PROVIDER_MAP = {
    # OpenAI
    "gpt-4o":          "openai",
    "gpt-4o-mini":     "openai",
    "gpt-4-turbo":     "openai",
    "gpt-4":           "openai",
    "gpt-3.5-turbo":   "openai",
    "gpt-5":           "openai",

    # Anthropic
    "claude-3":                        "anthropic",
    "claude-3-5-sonnet-20241022":      "anthropic",
    "claude-3-5-haiku-20241022":       "anthropic",
    "claude-3-opus-20240229":          "anthropic",
    "claude-3-sonnet-20240229":        "anthropic",
    "claude-3-haiku-20240307":         "anthropic",

    # Google Gemini
    "gemini-pro":          "gemini",
    "gemini-1.5-pro":      "gemini",
    "gemini-1.5-flash":    "gemini",
    "gemini-2.0-flash":    "gemini",

    # Groq-hosted models
    "llama-3.1-8b-instant":   "groq",
    "llama-3.1-70b-versatile":"groq",
    "llama3-70b-8192":        "groq",
    "mixtral-8x7b-32768":     "groq",
    "gemma2-9b-it":           "groq",
}


def _get_provider(model_name: str) -> str:
    """
    Determine provider from model name.
    Falls back to prefix matching if exact key not found.
    """
    if not model_name:
        return "groq"

    # Exact match first
    if model_name in MODEL_PROVIDER_MAP:
        return MODEL_PROVIDER_MAP[model_name]

    # Prefix matching for unknown versions (e.g. "gpt-4o-2024-11-20")
    lower = model_name.lower()
    if lower.startswith("gpt"):
        return "openai"
    if lower.startswith("claude"):
        return "anthropic"
    if lower.startswith("gemini"):
        return "gemini"
    if any(lower.startswith(p) for p in ["llama", "mixtral", "gemma", "whisper"]):
        return "groq"

    logger.warning(
        f"[ProviderRouter] Unknown model '{model_name}', defaulting to groq"
    )
    return "groq"


def generate(messages: list, model: str = None) -> str:
    """
    Route messages to the correct LLM provider based on model name.
    Drop-in replacement for groq_adapter.generate().
    """
    provider = _get_provider(model)

    logger.info(f"[ProviderRouter] model='{model}' → provider='{provider}'")

    if provider == "groq":
        from app.adapters.groq_adapter import generate as groq_generate
        return groq_generate(messages, model)

    elif provider == "openai":
        from app.adapters.openai_adapter import generate as openai_generate
        return openai_generate(messages, model)

    elif provider == "anthropic":
        from app.adapters.anthropic_adapter import generate as anthropic_generate
        return anthropic_generate(messages, model)

    elif provider == "gemini":
        from app.adapters.gemini_adapter import generate as gemini_generate
        return gemini_generate(messages, model)

    else:
        raise NonRetryableStepError(
            f"No adapter registered for provider: {provider}",
            error_type="CONFIG_ERROR"
        )