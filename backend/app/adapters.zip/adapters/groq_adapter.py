from groq import Groq
import os
import logging
from dotenv import load_dotenv
from app.runtime.errors import RetryableStepError, NonRetryableStepError

load_dotenv()

GROQ_DEFAULT_MODEL = os.getenv("GROQ_DEFAULT_MODEL", "llama-3.1-8b-instant")

GROQ_DECOMMISSIONED_MODELS = {
    "llama3-8b-8192"
}

MODEL_ALIASES = {
    "gpt-4o": GROQ_DEFAULT_MODEL,
    "gpt-4o (openai)": GROQ_DEFAULT_MODEL,
    "claude 3.5 (anthropic)": GROQ_DEFAULT_MODEL,
    "llama 3 (meta)": "llama-3.1-8b-instant",
    "gemini (google)": GROQ_DEFAULT_MODEL,
}


def get_client():
    api_key = os.getenv("GROQ_API_KEY")

    if not api_key:
        raise Exception("GROQ_API_KEY not set")

    return Groq(api_key=api_key)


def generate(messages, model=None):
    model_name = normalize_model_name(model or GROQ_DEFAULT_MODEL)

    try:
        client = get_client()

        response = client.chat.completions.create(
            model=model_name,
            messages=messages
        )
        return response.choices[0].message.content

    except Exception as e:
        message = str(e).lower()
        logging.error("Groq error: %s", message)

        # fallback if model deprecated
        if "model_decommissioned" in message or "model_not_found" in message:
            logging.warning("Model deprecated, retrying with default model")

            client = get_client()

            try:
                response = client.chat.completions.create(
                    model=normalize_model_name(GROQ_DEFAULT_MODEL),
                    messages=messages
                )
                return response.choices[0].message.content
            except Exception as fallback_error:
                raise RetryableStepError(
                    str(fallback_error),
                    error_type="LLM_PROVIDER_ERROR"
                )

        # Retryable patterns
        retryable_keywords = [
            "timeout",
            "rate limit",
            "temporarily unavailable",
            "connection",
            "503",
            "502",
            "429",
            "internal server error"
        ]

        if any(keyword in message for keyword in retryable_keywords):
            raise RetryableStepError(str(e), error_type="LLM_PROVIDER_ERROR")

        # Non-retryable patterns
        non_retryable_keywords = [
            "invalid api key",
            "authentication",
            "unauthorized",
            "invalid request",
            "bad request",
            "unsupported model"
        ]

        if any(keyword in message for keyword in non_retryable_keywords):
            raise NonRetryableStepError(str(e), error_type="AUTH_OR_CONFIG_ERROR")

        raise RetryableStepError(str(e), error_type="UNKNOWN_LLM_ERROR")


def normalize_model_name(model_name: str) -> str:
    if not model_name:
        return GROQ_DEFAULT_MODEL

    normalized = str(model_name).strip()
    alias = MODEL_ALIASES.get(normalized.lower())

    if alias:
        return alias

    if normalized.lower().startswith("gpt-"):
        return GROQ_DEFAULT_MODEL

    return normalized
