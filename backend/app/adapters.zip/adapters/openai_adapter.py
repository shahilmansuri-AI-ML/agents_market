import os
import logging
from dotenv import load_dotenv
from app.runtime.errors import RetryableStepError, NonRetryableStepError

load_dotenv()

logger = logging.getLogger(__name__)

OPENAI_DEFAULT_MODEL = os.getenv("OPENAI_DEFAULT_MODEL", "gpt-4o")

api_key = os.getenv("OPENAI_API_KEY")


def generate(messages, model=None):
    # Import here so missing package only fails if OpenAI is actually used
    try:
        from openai import OpenAI
    except ImportError:
        raise NonRetryableStepError(
            "openai package not installed. Run: pip install openai",
            error_type="MISSING_DEPENDENCY"
        )

    if not api_key:
        raise NonRetryableStepError(
            "OPENAI_API_KEY not set in environment",
            error_type="AUTH_OR_CONFIG_ERROR"
        )

    client = OpenAI(api_key=api_key)
    model_name = model or OPENAI_DEFAULT_MODEL

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=messages
        )
        return response.choices[0].message.content

    except Exception as e:
        message = str(e).lower()
        logger.error("OpenAI error: %s", message)

        retryable_keywords = [
            "timeout", "rate limit", "rate_limit", "temporarily unavailable",
            "connection", "503", "502", "429", "internal server error"
        ]
        if any(k in message for k in retryable_keywords):
            raise RetryableStepError(str(e), error_type="LLM_PROVIDER_ERROR")

        non_retryable_keywords = [
            "invalid api key", "authentication", "unauthorized",
            "invalid request", "bad request", "unsupported model",
            "model_not_found"
        ]
        if any(k in message for k in non_retryable_keywords):
            raise NonRetryableStepError(str(e), error_type="AUTH_OR_CONFIG_ERROR")

        raise RetryableStepError(str(e), error_type="UNKNOWN_LLM_ERROR")