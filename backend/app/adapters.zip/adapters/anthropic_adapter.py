import os
import logging
from dotenv import load_dotenv
from app.runtime.errors import RetryableStepError, NonRetryableStepError

load_dotenv()

logger = logging.getLogger(__name__)

ANTHROPIC_DEFAULT_MODEL = os.getenv("ANTHROPIC_DEFAULT_MODEL", "claude-3-5-sonnet-20241022")

api_key = os.getenv("ANTHROPIC_API_KEY")


def generate(messages, model=None):
    try:
        import anthropic
    except ImportError:
        raise NonRetryableStepError(
            "anthropic package not installed. Run: pip install anthropic",
            error_type="MISSING_DEPENDENCY"
        )

    if not api_key:
        raise NonRetryableStepError(
            "ANTHROPIC_API_KEY not set in environment",
            error_type="AUTH_OR_CONFIG_ERROR"
        )

    client = anthropic.Anthropic(api_key=api_key)
    model_name = model or ANTHROPIC_DEFAULT_MODEL

    # Anthropic separates system prompt from messages
    system_prompt = ""
    anthropic_messages = []

    for msg in messages:
        if msg["role"] == "system":
            system_prompt = msg["content"]
        else:
            anthropic_messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })

    try:
        kwargs = {
            "model": model_name,
            "max_tokens": 2048,
            "messages": anthropic_messages
        }
        if system_prompt:
            kwargs["system"] = system_prompt

        response = client.messages.create(**kwargs)
        return response.content[0].text

    except Exception as e:
        message = str(e).lower()
        logger.error("Anthropic error: %s", message)

        retryable_keywords = [
            "timeout", "rate limit", "overloaded", "temporarily unavailable",
            "503", "502", "429", "internal server error"
        ]
        if any(k in message for k in retryable_keywords):
            raise RetryableStepError(str(e), error_type="LLM_PROVIDER_ERROR")

        non_retryable_keywords = [
            "api key", "authentication", "unauthorized",
            "invalid request", "bad request", "not found"
        ]
        if any(k in message for k in non_retryable_keywords):
            raise NonRetryableStepError(str(e), error_type="AUTH_OR_CONFIG_ERROR")

        raise RetryableStepError(str(e), error_type="UNKNOWN_LLM_ERROR")